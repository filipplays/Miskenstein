/*
 * ray_funkcije.h
 *
 *  Created on: May 16, 2022
 *      Author: zevni
 */
#ifndef INCLUDE_RAY_FUNKCIJE_H_
#define INCLUDE_RAY_FUNKCIJE_H_


void drawGun();
void drawMap();


#endif /* INCLUDE_RAY_FUNKCIJE_H_ */
